﻿CryptoverseCTF 2022

Sahil Bugade (http://snip3r.me)

**Problem Statement:**

![](Aspose.Words.3c39790c-4a02-425e-80b4-7f2526c2892c.001.jpeg)

Given cipher text: cGlwZ3N7cG5yZm5lXzY0X3Nnan0=

Now after solving a bit of crypto CTFs we were easily able to guess that the given cipher text was encoded in base64. So firstly we decoded it from base64.

![](Aspose.Words.3c39790c-4a02-425e-80b4-7f2526c2892c.002.jpeg)

As you can see the decode text is “pipgs{pnrfne\_64\_sgj}” which can be identified as a format that a flag would be written in but isn’t the actual flag as the competition had its flag format “cvctf{}”.

So hereby, I saw that the output we got had (PiPgs) repeated “P” and the flag format (CvCtf) had “C” repeated. So I calculated how far is the alphabet “C” from “P” and came out to be 13 letters ahead.

So I calculated manually each and every alphabet 13 ahead of the given decoded form and came out with the flag cvctf{caesar\_64\_ftw}.

Later I came to know that such type of encryption is called ROT-13 encryption and could be found on the site: <https://www.dcode.fr/rot-13-cipher>.

![](Aspose.Words.3c39790c-4a02-425e-80b4-7f2526c2892c.003.jpeg)

Flag: cvctf{caesar\_64\_ftw}

It was our first international CTF, so overall we enjoyed it and to mention teamwork is always a key to success!
